@echo off
echo ============================================
echo  Build OTA Updater .exe
echo ============================================
echo.

:: Install dependencies jika belum ada
echo [1/3] Cek dan install PyInstaller...
pip install pyinstaller --quiet
if %errorlevel% neq 0 (
    echo ERROR: pip tidak ditemukan. Install Python dulu dari python.org
    pause
    exit /b 1
)

echo.
echo [2/3] Build .exe (ini mungkin 1-2 menit)...
pyinstaller ^
    --onefile ^
    --windowed ^
    --name "LivinaPro_OTA_Updater" ^
    --icon NONE ^
    ota_updater.py

if %errorlevel% neq 0 (
    echo.
    echo ERROR: Build gagal. Lihat pesan di atas.
    pause
    exit /b 1
)

echo.
echo [3/3] Selesai!
echo.
echo File .exe ada di: dist\LivinaPro_OTA_Updater.exe
echo Ukuran kira-kira 10-15 MB (normal untuk PyInstaller)
echo.
echo Kirim file ini ke customer via WhatsApp / Telegram / Google Drive.
echo.
pause
